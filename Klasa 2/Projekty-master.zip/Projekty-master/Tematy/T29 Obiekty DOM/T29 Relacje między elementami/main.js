const title = document.querySelector('.title')
console.log(title.firstChild)

const container = document.querySelector('.container')
const text = container.firstElementChild.firstChild
console.log(text)