liczby = [11, 23, 57, 94, 32];

for(let el of liczby){
    console.log(el)
}

