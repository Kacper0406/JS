var wojownik = {
    nazwa: "Mieszko",
    punkty_doswiadczenia: 5,
    punkty_zycia: 0.6,
    uzbrojenie: ['miecz', 'szyszak']
};

wojownik.uzbrojenie.push('szyszak')

console.log("Nazwa: " + wojownik.nazwa);
console.log("Doswiadczenie: " + wojownik.punkty_doswiadczenia);
console.log("Zycie: " + wojownik.punkty_zycia)
console.log("Uzbrojenie: " + wojownik.uzbrojenie);