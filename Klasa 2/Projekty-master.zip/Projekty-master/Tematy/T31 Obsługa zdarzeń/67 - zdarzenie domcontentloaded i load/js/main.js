window.addEventListener("load", function() {
    const img = document.querySelector("img");

    console.log(`Wymiary obrazka to: ${img.offsetWidth}x${img.offsetHeight}px`);
});

// document.addEventListener("DOMContentLoaded", function() {
//     const h1 = document.querySelector("h1");

//     console.log(h1.textContent);
// });

const h1 = document.querySelector("h1");

console.log(h1.textContent);
