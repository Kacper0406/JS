let b = 2;
let a = (b===2) || (b>3);

console.log('a = '+ a)
console.log('b = '+ b)
console.log("Typ zmiennej a: " + typeof(a));
console.log("Typ zmiennej b: " + typeof(b));

document.write(a);
document.write('<br>' + b);