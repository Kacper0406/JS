// przyklad 3.23
for (let i = 0; i < 5;) {
    document.write(`Pętla wykonana ${i} raz/y<br>`);
    i++;
}