window.location.href = "http://www.helion.pl"
window.location = "https://www.google.pl/search?q=warszawa+lotnisko"