//3.21
var a = 20;
var b = 7;
switch (a * b) {
    case 10:
        document.write("Wynik mnożenia wynosi 10.");
        break;
    case 40:
        document.write("Wynik mnożenia wynosi 40.");
        break;
    case 100:
        document.write("Wynik mnożenia wynosi 100.");
        break;
    default:
        document.write("Nieznany wynik mnożenia.");
}