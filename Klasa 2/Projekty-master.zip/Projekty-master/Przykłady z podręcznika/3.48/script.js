//3.48
osoba1.nazwisko;
osoba1.["nazwisko"];