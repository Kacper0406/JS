//Przykład 3.26
var i = 1;
do {
    document.write("Pętla wykonana" + i + "raz/y<br>");
} while (i++ <= 5);