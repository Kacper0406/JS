function zmien_tekst()
{
document.getElementById('blok').innerHTML = 'Jesień mimozami się'
}