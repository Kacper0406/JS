// Przykład 3.61
var Osoby = [];
Osoby[0] = ['Anna', 'Nowak'];
Osoby[1] = ['Adam', 'Kowal'];
Osoby[2] = ['Piotr', 'Ogórek'];
Osoby[3] = ['Ewa', 'Lisowska'];
document.write('imię: ' + Osoby[0][0] + ', nazwisko: ' + Osoby[0][1]
    + "<br>");
document.write('imię: ' + Osoby[1][0] + ', nazwisko: ' + Osoby[1][1]
    + "<br>");
document.write('imię: ' + Osoby[2][0] + ', nazwisko: ' + Osoby[2][1]
    + "<br>");
document.write('imię: ' + Osoby[3][0] + ', nazwisko: ' + Osoby[3][1]);