//Przykład 3.17
for (var i = 0; i < 10; i++) {
    document.write("<br> Ile razy zostanie wykonana pętla? " + i);
}