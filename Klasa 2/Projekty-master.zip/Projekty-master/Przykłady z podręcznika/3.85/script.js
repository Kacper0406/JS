document.addEventListener("DOMContentLoaded", function() {
console.log("DOM został wczytany");
});