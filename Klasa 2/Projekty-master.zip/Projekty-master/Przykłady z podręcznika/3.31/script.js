// Przykład 3.31
function wynik(x, y) {
    var s = x + y;
    return s;
}
var suma = wynik(19, 7) + 27;
document.write("Wynik dodawania: " + suma);