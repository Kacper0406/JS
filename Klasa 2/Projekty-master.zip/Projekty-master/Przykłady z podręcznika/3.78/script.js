var b = document.getElementById("klik");
document.write("<br>Tekst z przycisku: " + b.value);