// Przykład 3.22
for (var i = 0; i < 5; i++) {
    document.write("Pętla wykonana " + i + " raz/y<br>");
}