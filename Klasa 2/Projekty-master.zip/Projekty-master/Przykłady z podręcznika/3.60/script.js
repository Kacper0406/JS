//3.60
var imie = ['Anna', 'Adam', 'Piotr', 'Ewa', 'Paweł', 'Marcin', 'Ela'];
for (var i = 0; i < imie.length; i++) {
    document.write(imie[i] + "<br>");
}