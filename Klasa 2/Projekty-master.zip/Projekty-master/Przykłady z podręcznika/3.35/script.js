// przykład 3.35
let a = 10;
let a = 15;
document.write("Zmienna w bloku: " + a);
document.write("Zmienna globalna: " + a);