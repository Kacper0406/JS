//Przykład 3.14
var osoba = {nazwisko: "Nowak", imie: "Paweł", wiek: 18};3.14