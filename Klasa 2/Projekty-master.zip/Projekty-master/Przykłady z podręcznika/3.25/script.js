// Przykład 3.25
var i = 0;
while (i++ < 5) {
    document.write("Pętla wykonana " + i + " raz/y<br>");
}