
document.write("Masz przeglądarkę: ");
document.write(navigator.appName + "<br>");
document.write("Język przeglądarki: ");
document.write(navigator.language + "<br>");
document.write("Platforma: ");
document.write(navigator.platform)