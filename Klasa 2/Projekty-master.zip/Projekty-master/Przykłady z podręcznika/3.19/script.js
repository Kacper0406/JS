//przyklad 3.19
    var a = 10;
    var b = '10';
    if (a === b) {document.write("Liczby są identyczne.");
}
    else {
    document.write("Liczby nie są identyczne.");
}