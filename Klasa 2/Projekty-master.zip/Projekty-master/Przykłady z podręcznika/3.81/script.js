var link1 = links[0].href;
