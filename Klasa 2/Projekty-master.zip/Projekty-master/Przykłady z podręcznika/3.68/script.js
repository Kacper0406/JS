// przykład 3.68
let data = new Date(2019, 2, 27);