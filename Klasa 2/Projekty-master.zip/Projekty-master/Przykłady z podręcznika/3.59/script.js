//Przykład 3.59
var tab5 = ['kot', 'pies', 'koń'];
tab5[3] = 'mysz';
tab5[4] = 'chomik';
document.write(tab5[0] + ' i ' + tab5[3]);