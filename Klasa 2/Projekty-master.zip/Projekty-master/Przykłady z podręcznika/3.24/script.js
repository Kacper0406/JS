//Przykład 3.24
var i = 0;
for (; i < 5;) {
    document.write("Pętla wykonana " + i + " raz/y<br>");
    i++;
}