//Przykład 3.47
var osoba1 = new Klient('Kowalski', 'Jan', 'kierowca');
var osoba2 = new Klient('Nowak', 'Anna', 'sekretarka');