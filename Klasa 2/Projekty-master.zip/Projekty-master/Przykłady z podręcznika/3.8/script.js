// przykład 3.8
// tutaj znajduje się komentarz
let b = 5, c = 4 // deklaracja zmiennych
let a = b + c // suma wartości