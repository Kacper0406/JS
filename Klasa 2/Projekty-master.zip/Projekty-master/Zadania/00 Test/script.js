var imie = prompt("Witaj, jak się nazywasz?", "Anonim");
document.getElementById("name").innerHTML = "Witaj! " + imie + " 👋";