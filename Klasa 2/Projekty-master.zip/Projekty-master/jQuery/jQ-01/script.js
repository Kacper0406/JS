$( "h1" ).html( "Komunikat" )
alert("Komunikat")