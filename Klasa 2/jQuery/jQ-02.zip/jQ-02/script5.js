$( "button" ).on( "click", function( event ) {
    $( "#box" ).hide(1000)
});